<?php

namespace League\Flysystem;

class Exception extends \Exception
{
    //
}
